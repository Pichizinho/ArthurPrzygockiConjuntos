#  Arthur Przygocki
#O  programa  que  você  desenvolverá  irá  receber  como  entrada um arquivo de texto  (.txt) contendo vários conjuntos de dados e várias operações. Estas operações e dados estarão representadas em um arquivo de textos contendo apenas os dados referentes as operações que devem ser realizadas segundo a seguinte regra fixa: a primeira linha do arquivo de texto de entrada conterá o número de operações  que  estão  descritas  no  arquivo,  este  número  de  operações  será  um  inteiro;  as  linhas seguintes  seguirão  sempre  o  mesmo  padrão  de  três  linhas:  a  primeira  linha  apresenta  o  código  da operação  (U para união, I para interseção, D para diferença e C produto cartesiano),  a  segunda  e terceira linhas conterão os elementos dos conjuntos separados por virgulas.
################################################
#Abrir arquivo e armazenar em uma lista
with open('conjunto0.txt') as arquivo:
    mensagem = arquivo.readlines()
conjuntos = [l.strip() for l in mensagem]
################################################
#Converter conjuntos[0] para inteiro
linhaConj = conjuntos[0]
listaConj = linhaConj.split(", ")
mapearConj = map(int, listaConj)
conjuntoConj = list(mapearConj)
numero = conjuntoConj[0]
numeroConvertido = int(numero) 
#################################################
#Variáveis
posicao = 0

#################################################
#Funções
def Separar(posicao):
  posicao = int(posicao)
  stringPosicao = conjuntos[posicao]
  listaPosicao = stringPosicao.split(", ")
  mapearPosicao = map(str, listaPosicao)
  conjuntoPosicao = list(mapearPosicao)
  return conjuntoPosicao

def Chaves(nomeResultado):
  listaChaves = nomeResultado
  listaString = str(listaChaves)
  novaLista1 = listaString.replace('[','{')
  novaLista2 = novaLista1.replace(']','}')
  novaLista3 = novaLista2.replace("'","")
  return novaLista3
  
def Uniao():
  resultadoUniao = []
  u = 0
  while u < (len(listaUniao1)):
      resultadoUniao.append(listaUniao1[u])
      u += 1
  u = 0
  while u < (len(listaUniao2)):
      if listaUniao2[u] not in resultadoUniao:
        resultadoUniao.append(listaUniao2[u])
      u += 1
  return resultadoUniao

def Intersecao():
    i = 0
    resultadoInter = []
    while i < (len(listaInter1)):
      if listaInter1[i] in listaInter2:
        resultadoInter.append(listaInter1[i])
      i += 1
    return resultadoInter

def Diferenca():
  resultadoDif = []
  for d in range(len(listaDif1)):
    if listaDif1[d] not in listaDif2:
      resultadoDif.append(listaDif1[d])
  return resultadoDif
  
def Produto():
    r = [(x, y) for x in listaProd1 for y in listaProd2]
    return r
#################################################
if numeroConvertido == 4:
  i = 0
  listaUniao1 = Separar(2)
  listaUniao2 = Separar(3)
  listaInter1 = Separar(5)
  listaInter2 = Separar(6)
  listaDif1 = Separar(8)
  listaDif2 = Separar(9)
  listaProd1 = Separar(11)
  listaProd2 = Separar(12)
  print("União: conjunto 1", Chaves(listaUniao1),"conjunto 2", Chaves(listaUniao2),". Resultado: ", Chaves(Uniao()))
  print("Interseção: conjunto 1", Chaves(listaInter1),"conjunto 2", Chaves(listaInter2),". Resultado: ", Chaves(Intersecao()))
  print("Diferenca: conjunto 1", Chaves(listaDif1),"conjunto 2", Chaves(listaDif2),". Resultado: ", Chaves(Diferenca()))
  print("Produto Cartesiano: conjunto 1", Chaves(listaProd1),"conjunto 2", Chaves(listaProd2),". Resultado: ", Chaves(Produto()))
if numeroConvertido == 3:
  listaUniao1 = Separar(2)
  listaUniao2 = Separar(3)
  listaInter1 = Separar(5)
  listaInter2 = Separar(6)
  listaDif1 = Separar(8)
  listaDif2 = Separar(9)
  print("União: conjunto 1", Chaves(listaUniao1),"conjunto 2", Chaves(listaUniao2),". Resultado: ", Chaves(Uniao()))
  print("Interseção: conjunto 1", Chaves(listaInter1),"conjunto 2", Chaves(listaInter2),". Resultado: ", Chaves(Intersecao()))
  print("Diferenca: conjunto 1", Chaves(listaDif1),"conjunto 2", Chaves(listaDif2),". Resultado: ", Chaves(Diferenca()))
if numeroConvertido == 2:
  listaUniao1 = Separar(2)
  listaUniao2 = Separar(3)
  listaInter1 = Separar(5)
  listaInter2 = Separar(6)
  print("União: conjunto 1", Chaves(listaUniao1),"conjunto 2", Chaves(listaUniao2),". Resultado: ", Chaves(Uniao()))
  print("Interseção: conjunto 1", Chaves(listaInter1),"conjunto 2", Chaves(listaInter2),". Resultado: ", Chaves(Intersecao()))
if numeroConvertido == 1:
  listaUniao1 = Separar(2)
  listaUniao2 = Separar(3)
  print("União: conjunto 1", Chaves(listaUniao1),"conjunto 2", Chaves(listaUniao2),". Resultado: ", Chaves(Uniao()))